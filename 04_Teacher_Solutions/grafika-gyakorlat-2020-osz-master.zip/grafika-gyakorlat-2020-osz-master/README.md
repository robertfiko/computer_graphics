# Számítógépes grafika - 2020. ősz - 4. csoport

Honlap: http://cg.elte.hu/~szabozsombor/

Elérhetőség: Microsoft Teams-en
